//Je selectionne mon bouton dans le html
let bouton = document.getElementById("bouton");
//J'ajoute un evenement lors du clic du bouton
bouton.addEventListener("click", function(){
    alert("Page en construction, la suite arrive bientôt");
});